const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../../database/e-db.db');

// Create database connection
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Failed to connect to database:', err.message);
    } else {
        console.log('✅ Database connected');

        db.run('PRAGMA foreign_keys = ON');

        db.run('ALTER TABLE products ADD COLUMN image_path TEXT', () => {});
        db.run('ALTER TABLE products ADD COLUMN thumbnail_path TEXT', () => {});

        db.run(`
            CREATE TABLE IF NOT EXISTS product_images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pid INTEGER,
                image_path TEXT,
                thumbnail_path TEXT,
                sort_order INTEGER DEFAULT 0,
                FOREIGN KEY (pid) REFERENCES products(pid) ON DELETE CASCADE
            )
        `, () => {
            db.run('ALTER TABLE product_images ADD COLUMN pid INTEGER', () => {});
            db.run('ALTER TABLE product_images ADD COLUMN image_path TEXT', () => {});
            db.run('ALTER TABLE product_images ADD COLUMN thumbnail_path TEXT', () => {});
            db.run('ALTER TABLE product_images ADD COLUMN sort_order INTEGER DEFAULT 0', () => {});
        });

    }
});

// Wrap sqlite methods as Promises for async/await
db.runAsync = function(sql, params = []) {
    return new Promise((resolve, reject) => {
        this.run(sql, params, function(err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
};

db.getAsync = function(sql, params = []) {
    return new Promise((resolve, reject) => {
        this.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
};

db.allAsync = function(sql, params = []) {
    return new Promise((resolve, reject) => {
        this.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
};

module.exports = db;